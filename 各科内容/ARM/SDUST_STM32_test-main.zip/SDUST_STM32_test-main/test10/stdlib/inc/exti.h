#ifndef __EXTI_H
#define __EXTI_H

#include "stm32f10x.h"

void EXTIX_Init(void);
void EXTI2_IRQHandler(void);

#endif

